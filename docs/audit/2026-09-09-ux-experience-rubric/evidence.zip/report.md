# 真实旅程体验报告

执行时间：2026-09-08T20:18:35.686Z · 应用 d566c99c3d87a5a0264955c161575a13b2e5d692 · loopback · 模型费用 0

机械规则通过仅表示代理检查通过；主观理解、舒适度仍待评审。初次基线记录现状，不代表认可。

## Agent 对话完成一次工具调用

首屏可操作代理：3075 ms（含测试观测开销；不是 TTI）。

任务：已完成 · 7 个阶段 · 基线：pass · [执行证据](runs/agent-panel/steps.json) · [Trace](runs/agent-panel/trace.zip)

| 维度 | 机械分（非体验分） | 主观分 | 结果 |
| --- | --- | --- | --- |
| 链路长度 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 每步可理解 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 图标可懂 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 文案简洁 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 目标可理解 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 整齐 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 空间舒适 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 伸手 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 速度 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 机械体感缺陷 | 1 | 待评审 | 7 条机械提醒；不代表主观体验评分 |

| 度量 | 本次 | 原基线 |
| --- | --- | --- |
| clicks | 5.00 | 5.00 |
| inputs | 1.00 | 1.00 |
| keys | 1.00 | 1.00 |
| scrolls | 0.00 | 0.00 |
| panelSwitches | 1.00 | 1.00 |
| confirmations | 0.00 | 0.00 |
| unnamedIconCount | 0.00 | 0.00 |
| longCopyCount | 0.00 | 0.00 |
| pointerDistancePx | 1620.48 | 1620.48 |
| fittsSum | 12.00 | 12.00 |
| feelFindings | 12.00 | 12.00 |

| 维度 / 指标 | 证据 | 疑似 owner | 建议 |
| --- | --- | --- | --- |
| feel / feelFindings: 5 > 0 | [new-project](runs/agent-panel/01-new-project-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 11 > 0 | [open-models](runs/agent-panel/02-open-models-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 12 > 0 | [open-chat-model](runs/agent-panel/03-open-chat-model-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 11 > 0 | [choose-model](runs/agent-panel/04-choose-model-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 5 > 0 | [close-models](runs/agent-panel/05-close-models-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 5 > 0 | [write-instruction](runs/agent-panel/06-write-instruction-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 11 > 0 | [send-instruction](runs/agent-panel/07-send-instruction-after.png) | src/workbench/ai | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |

主观分诊：每步下一行动、图标盲猜、文案复述、首屏目标、空间舒适均待人工/VLM；不以离线规则冒充通过。

## 画布生成一张图

首屏可操作代理：1631 ms（含测试观测开销；不是 TTI）。

任务：已完成 · 8 个阶段 · 基线：pass · [执行证据](runs/canvas-image/steps.json) · [Trace](runs/canvas-image/trace.zip)

| 维度 | 机械分（非体验分） | 主观分 | 结果 |
| --- | --- | --- | --- |
| 链路长度 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 每步可理解 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 图标可懂 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 文案简洁 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 目标可理解 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 整齐 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 空间舒适 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 伸手 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 速度 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 机械体感缺陷 | 1 | 待评审 | 8 条机械提醒；不代表主观体验评分 |

| 度量 | 本次 | 原基线 |
| --- | --- | --- |
| clicks | 7.00 | 7.00 |
| inputs | 1.00 | 1.00 |
| keys | 0.00 | 0.00 |
| scrolls | 0.00 | 0.00 |
| panelSwitches | 4.00 | 4.00 |
| confirmations | 1.00 | 1.00 |
| unnamedIconCount | 0.00 | 0.00 |
| longCopyCount | 0.00 | 0.00 |
| pointerDistancePx | 2495.12 | 2495.12 |
| fittsSum | 20.89 | 20.89 |
| feelFindings | 61.00 | 61.00 |

| 维度 / 指标 | 证据 | 疑似 owner | 建议 |
| --- | --- | --- | --- |
| feel / feelFindings: 5 > 0 | [new-project](runs/canvas-image/01-new-project-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 8 > 0 | [open-canvas](runs/canvas-image/02-open-canvas-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 11 > 0 | [add-image](runs/canvas-image/03-add-image-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 14 > 0 | [select-model](runs/canvas-image/04-select-model-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 11 > 0 | [choose-model](runs/canvas-image/05-choose-model-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 11 > 0 | [write-prompt](runs/canvas-image/06-write-prompt-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 61 > 0 | [generate](runs/canvas-image/07-generate-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 20 > 0 | [confirm-generation](runs/canvas-image/08-confirm-generation-after.png) | src/workbench/generationCanvas | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |

主观分诊：每步下一行动、图标盲猜、文案复述、首屏目标、空间舒适均待人工/VLM；不以离线规则冒充通过。

## 设置页接入模型

首屏可操作代理：1512 ms（含测试观测开销；不是 TTI）。

任务：已完成 · 10 个阶段 · 基线：pass · [执行证据](runs/settings-model/steps.json) · [Trace](runs/settings-model/trace.zip)

| 维度 | 机械分（非体验分） | 主观分 | 结果 |
| --- | --- | --- | --- |
| 链路长度 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 每步可理解 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 图标可懂 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 文案简洁 | 1 | 待评审 | 1 条机械提醒；不代表主观体验评分 |
| 目标可理解 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 整齐 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 空间舒适 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 伸手 | — | 待评审 | 离线不能判断此维体验；请结合证据评审 |
| 速度 | 3 | 待评审 | 0 条机械提醒；不代表主观体验评分 |
| 机械体感缺陷 | 1 | 待评审 | 10 条机械提醒；不代表主观体验评分 |

| 度量 | 本次 | 原基线 |
| --- | --- | --- |
| clicks | 7.00 | 7.00 |
| inputs | 3.00 | 3.00 |
| keys | 0.00 | 0.00 |
| scrolls | 0.00 | 0.00 |
| panelSwitches | 3.00 | 3.00 |
| confirmations | 0.00 | 0.00 |
| unnamedIconCount | 0.00 | 0.00 |
| longCopyCount | 9.00 | 9.00 |
| pointerDistancePx | 2559.01 | 2559.01 |
| fittsSum | 16.75 | 16.75 |
| feelFindings | 78.00 | 78.00 |

| 维度 / 指标 | 证据 | 疑似 owner | 建议 |
| --- | --- | --- | --- |
| copy / longCopyCount: 9 > 0 | [open-models](runs/settings-model/02-open-models-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 文案简洁 的截图与原始测量；字符数按Unicode码点；用户输入值不参与，模型名和任务内容不是默认缺陷 |
| feel / feelFindings: 9 > 0 | [open-settings](runs/settings-model/01-open-settings-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 78 > 0 | [open-models](runs/settings-model/02-open-models-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 17 > 0 | [custom-api](runs/settings-model/03-custom-api-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 17 > 0 | [connection-name](runs/settings-model/04-connection-name-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 17 > 0 | [connection-url](runs/settings-model/05-connection-url-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 17 > 0 | [connection-key](runs/settings-model/06-connection-key-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 10 > 0 | [save-connection](runs/settings-model/07-save-connection-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 37 > 0 | [fetch-models](runs/settings-model/08-fetch-models-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 37 > 0 | [choose-model](runs/settings-model/09-choose-model-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |
| feel / feelFindings: 17 > 0 | [verify-model](runs/settings-model/10-verify-model-after.png) | src/ui/onboarding/ModelSettingsHome.tsx | 复核 机械体感缺陷 的截图与原始测量；原样保留第一层候选，未经人工确认不能称产品bug |

主观分诊：每步下一行动、图标盲猜、文案复述、首屏目标、空间舒适均待人工/VLM；不以离线规则冒充通过。

## 本次未选中的登记

- artifact-products：not-selected（未执行，不声称通过）
- storyboard-timeline-export：not-selected（未执行，不声称通过）
